package com.fare.service.impl;

import org.springframework.stereotype.Service;

import com.fare.dto.FareRequest;
import com.fare.dto.FareResponse;
import com.fare.entity.Fare;
import com.fare.repository.FareRepository;
import com.fare.service.FareService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class FareServiceImpl implements FareService {
    private final FareRepository fareRepository;
    
    @Override
    public FareResponse addFare(FareRequest request) {
        log.info("Adding fare for train ID: {}, coach type: {}", request.getTrainId(), request.getCoachType());
        Fare fare = new Fare();
        fare.setTrainId(request.getTrainId());
        fare.setCoachType(request.getCoachType());
        fare.setAmount(request.getAmount());
        Fare saved = fareRepository.save(fare);
        log.debug("Fare saved successfully with ID: {}", saved.getId());
        return new FareResponse(
                saved.getTrainId(),
                saved.getCoachType(),
                saved.getAmount()
        );
    }

    @Override
    public FareResponse getFare(Long trainId, String coachType) {
        log.info("Fetching fare for train ID: {}, coach type: {}", trainId, coachType);
        Fare fare = fareRepository
                .findByTrainIdAndCoachType(trainId, coachType)
                .orElseThrow(() -> {
                    log.error("Fare not found for train ID: {}, coach type: {}", trainId, coachType);
                    return new RuntimeException("Fare not found");
                });
        log.debug("Fare retrieved successfully");
        return new FareResponse(
                fare.getTrainId(),
                fare.getCoachType(),
                fare.getAmount()
        );
    }
}