package com.fare.service;

import com.fare.dto.FareRequest;
import com.fare.dto.FareResponse;

public interface FareService {
    FareResponse addFare(FareRequest request);
    FareResponse getFare(Long trainId, String coachType);
}