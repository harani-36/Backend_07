package com.fare.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fare.entity.Fare;

public interface FareRepository extends JpaRepository<Fare, Long>{
	Optional<Fare> findByTrainIdAndCoachType(Long trainId, String coachType);

}
