package com.fare.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FareRequest {

    private Long trainId;
    private String coachType;
    private Double amount;
}
