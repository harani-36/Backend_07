package com.fare.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class FareResponse {

    private Long trainId;
    private String coachType;
    private Double amount;
}