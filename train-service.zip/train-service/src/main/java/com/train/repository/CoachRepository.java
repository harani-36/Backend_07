package com.train.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.train.entity.Coach;

public interface CoachRepository extends JpaRepository<Coach, Long> {}
