package com.train.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.train.entity.Train;

public interface TrainRepository extends JpaRepository<Train, Long>{

}
