package com.train.service.Impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.train.dto.CoachConfigRequest;
import com.train.dto.JourneyRequest;
import com.train.dto.JourneyResponse;
import com.train.entity.Coach;
import com.train.entity.Journey;
import com.train.entity.Seat;
import com.train.entity.SeatStatus;
import com.train.entity.Train;
import com.train.exception.ResourceNotFoundException;
import com.train.repository.JourneyRepository;
import com.train.repository.TrainRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class JourneyServiceImpl implements com.train.service.JourneyService {
    
    private static final Logger log = LoggerFactory.getLogger(JourneyServiceImpl.class);
    private final JourneyRepository journeyRepository;
    private final TrainRepository trainRepository;
    
    @Override
    @Transactional
    public JourneyResponse createJourney(JourneyRequest request) {
        log.debug("Creating journey for train ID: {} on date: {}", request.getTrainId(), request.getJourneyDate());
        
        Train train = trainRepository.findById(request.getTrainId())
                .orElseThrow(() -> new ResourceNotFoundException("Train not found with id: " + request.getTrainId()));
        
        // Check for time conflicts with existing journeys on the same date
        List<Journey> existingJourneys = journeyRepository.findByTrainIdAndJourneyDate(request.getTrainId(), request.getJourneyDate());
        for (Journey existing : existingJourneys) {
            // Check if times overlap: new journey starts before existing ends OR new journey ends after existing starts
            boolean overlaps = !(request.getArrivalTime().isBefore(existing.getDepartureTime()) || 
                                 request.getDepartureTime().isAfter(existing.getArrivalTime()));
            if (overlaps) {
                throw new IllegalArgumentException("Journey time conflict: Train is occupied from " + 
                    existing.getDepartureTime() + " to " + existing.getArrivalTime());
            }
        }
        
        Journey journey = new Journey();
        journey.setTrain(train);
        journey.setJourneyDate(request.getJourneyDate());
        journey.setDepartureTime(request.getDepartureTime());
        journey.setArrivalTime(request.getArrivalTime());
        
        List<Coach> coaches = generateCoaches(journey, request.getCoachConfigs());
        journey.setCoaches(coaches);
        
        Journey saved = journeyRepository.save(journey);
        
        int totalSeats = coaches.stream().mapToInt(c -> c.getSeats().size()).sum();
        log.info("Journey created successfully with ID: {}, Total seats: {}", saved.getId(), totalSeats);
        
        return mapToResponse(saved);
    }
    
    private List<Coach> generateCoaches(Journey journey, List<CoachConfigRequest> configs) {
        List<Coach> coaches = new ArrayList<>();
        Map<String, Integer> coachCounters = new HashMap<>();
        
        for (CoachConfigRequest config : configs) {
            String coachType = config.getCoachType();
            int numberOfCoaches = config.getNumberOfCoaches();
            int seatsPerCoach = config.getSeatsPerCoach();
            
            for (int i = 1; i <= numberOfCoaches; i++) {
                int coachNumber = coachCounters.getOrDefault(coachType, 0) + 1;
                coachCounters.put(coachType, coachNumber);
                
                Coach coach = new Coach();
                coach.setCoachNumber(coachType + coachNumber);
                coach.setCoachType(coachType);
                coach.setJourney(journey);
                
                List<Seat> seats = generateSeats(coach, seatsPerCoach);
                coach.setSeats(seats);
                
                coaches.add(coach);
            }
        }
        
        return coaches;
    }
    
    private List<Seat> generateSeats(Coach coach, int seatsPerCoach) {
        List<Seat> seats = new ArrayList<>();
        
        for (int i = 1; i <= seatsPerCoach; i++) {
            Seat seat = new Seat();
            seat.setSeatNumber(coach.getCoachNumber() + "-" + i);
            seat.setStatus(SeatStatus.AVAILABLE);
            seat.setCoach(coach);
            seats.add(seat);
        }
        
        return seats;
    }
    
    @Override
    public List<JourneyResponse> getAllJourneys() {
        log.debug("Fetching all journeys");
        return journeyRepository.findAll().stream()
                .map(this::mapToResponse)
                .toList();
    }
    
    @Override
    public JourneyResponse getJourneyById(Long id) {
        log.debug("Fetching journey with ID: {}", id);
        Journey journey = journeyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Journey not found with id: " + id));
        return mapToResponse(journey);
    }
    
    @Override
    public List<JourneyResponse> getJourneysByDate(LocalDate date) {
        log.debug("Fetching journeys for date: {}", date);
        return journeyRepository.findByJourneyDate(date).stream()
                .map(this::mapToResponse)
                .toList();
    }
    
    private JourneyResponse mapToResponse(Journey journey) {
        Train train = journey.getTrain();
        int totalSeats = journey.getCoaches().stream()
                .mapToInt(c -> c.getSeats().size())
                .sum();
        int availableSeats = journey.getCoaches().stream()
                .flatMap(c -> c.getSeats().stream())
                .filter(s -> s.getStatus() == SeatStatus.AVAILABLE)
                .mapToInt(s -> 1)
                .sum();
        
        return new JourneyResponse(
                journey.getId(),
                train.getId(),
                train.getTrainNumber(),
                train.getName(),
                train.getSource(),
                train.getDestination(),
                journey.getJourneyDate(),
                journey.getDepartureTime(),
                journey.getArrivalTime(),
                totalSeats,
                availableSeats
        );
    }
}
