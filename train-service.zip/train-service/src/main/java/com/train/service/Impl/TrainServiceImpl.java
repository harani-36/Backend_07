package com.train.service.Impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.train.client.FareClient;
import com.train.dto.FareResponse;
import com.train.dto.TrainFareResponse;
import com.train.dto.TrainRequest;
import com.train.dto.TrainResponse;
import com.train.entity.Train;
import com.train.repository.TrainRepository;
import com.train.service.TrainService;

import com.train.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TrainServiceImpl implements TrainService {

    private static final Logger log = LoggerFactory.getLogger(TrainServiceImpl.class);
    private final TrainRepository trainRepository;
    private final FareClient fareClient;
    
    @Override
    public TrainResponse addTrain(TrainRequest request) {
        log.debug("Adding new train: {}", request.getName());
        
        Train train = new Train();
        train.setTrainNumber(request.getTrainNumber());
        train.setName(request.getName());
        train.setSource(request.getSource());
        train.setDestination(request.getDestination());

        Train saved = trainRepository.save(train);
        log.info("Train added successfully with id: {}", saved.getId());

        return new TrainResponse(
                saved.getId(),
                saved.getTrainNumber(),
                saved.getName(),
                saved.getSource(),
                saved.getDestination()
        );
    }

    @Override
    public List<TrainResponse> getAllTrains() {
        log.debug("Fetching all trains");
        
        List<TrainResponse> trains = trainRepository.findAll()
                .stream()
                .map(train -> new TrainResponse(
                        train.getId(),
                        train.getTrainNumber(),
                        train.getName(),
                        train.getSource(),
                        train.getDestination()
                ))
                .toList();
        
        log.info("Retrieved {} trains", trains.size());
        return trains;
    }
    
    @Override
    public TrainFareResponse getTrainWithFare(Long trainId, String coachType) {
        log.debug("Fetching train with fare for trainId: {}, coachType: {}", trainId, coachType);
        
        Train train = trainRepository.findById(trainId)
                .orElseThrow(() -> {
                    log.error("Train not found with id: {}", trainId);
                    return new ResourceNotFoundException("Train not found");
                });
        
        try {
            log.info("Calling Fare Service for trainId: {}, coachType: {}", trainId, coachType);
            FareResponse fare = fareClient.getFare(trainId, coachType);
            log.info("Fare retrieved successfully: {}", fare.getAmount());
            
            return new TrainFareResponse(
                    train.getId(),
                    train.getName(),
                    train.getSource(),
                    train.getDestination(),
                    coachType,
                    fare.getAmount()
            );
        } catch (Exception e) {
            log.error("Failed to fetch fare from Fare Service: {}", e.getMessage());
            throw e;
        }
    }
}