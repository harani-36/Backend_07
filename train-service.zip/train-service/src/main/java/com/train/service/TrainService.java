package com.train.service;

import java.util.List;

import com.train.dto.TrainFareResponse;
import com.train.dto.TrainRequest;
import com.train.dto.TrainResponse;

public interface TrainService {
    TrainResponse addTrain(TrainRequest request);
    List<TrainResponse> getAllTrains();
    TrainFareResponse getTrainWithFare(Long trainId, String coachType);
}
