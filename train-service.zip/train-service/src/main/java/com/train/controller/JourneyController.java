package com.train.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.train.dto.JourneyRequest;
import com.train.dto.JourneyResponse;
import com.train.service.JourneyService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/journeys")
@RequiredArgsConstructor
public class JourneyController {
    
    private final JourneyService journeyService;
    
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<JourneyResponse> createJourney(@Valid @RequestBody JourneyRequest request) {
        JourneyResponse response = journeyService.createJourney(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    
    @GetMapping
    public ResponseEntity<List<JourneyResponse>> getAllJourneys() {
        List<JourneyResponse> journeys = journeyService.getAllJourneys();
        return ResponseEntity.ok(journeys);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<JourneyResponse> getJourneyById(@PathVariable Long id) {
        JourneyResponse journey = journeyService.getJourneyById(id);
        return ResponseEntity.ok(journey);
    }
    
    @GetMapping("/by-date")
    public ResponseEntity<List<JourneyResponse>> getJourneysByDate(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<JourneyResponse> journeys = journeyService.getJourneysByDate(date);
        return ResponseEntity.ok(journeys);
    }
}
