package com.train.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.train.dto.TrainFareResponse;
import com.train.dto.TrainRequest;
import com.train.dto.TrainResponse;
import com.train.entity.Seat;
import com.train.entity.SeatStatus;
import com.train.repository.SeatRepository;
import com.train.service.TrainService;

import com.train.exception.ResourceNotFoundException;
import com.train.exception.SeatAlreadyBookedException;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/trains")
@RequiredArgsConstructor
public class TrainController {
    
    private static final Logger log = LoggerFactory.getLogger(TrainController.class);
    private final TrainService trainService;
    private final SeatRepository seatRepository;
    
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public TrainResponse addTrain(@Valid @RequestBody TrainRequest request) {
        log.info("Add train request received: {}", request.getName());
        return trainService.addTrain(request);
    }
    
    @GetMapping
    public List<TrainResponse> getAllTrains() {
        log.info("Get all trains request received");
        return trainService.getAllTrains();
    }
    
    @GetMapping("/{id}/fare")
    public TrainFareResponse getTrainWithFare(
            @PathVariable Long id,
            @RequestParam String coachType) {
        log.info("Get train with fare request for trainId: {}, coachType: {}", id, coachType);
        return trainService.getTrainWithFare(id, coachType);
    }
    
    @PutMapping("/seats/{seatId}/book")
    @Transactional
    public void bookSeat(@PathVariable Long seatId) {
        log.info("Book seat request for seatId: {}", seatId);
        
        Seat seat = seatRepository.findSeatForUpdate(seatId)
                .orElseThrow(() -> {
                    log.error("Seat not found with id: {}", seatId);
                    return new ResourceNotFoundException("Seat not found");
                });

        if (seat.getStatus() == SeatStatus.BOOKED) {
            log.error("Seat already booked: {}", seatId);
            throw new SeatAlreadyBookedException("Seat already booked");
        }
        
        seat.setStatus(SeatStatus.BOOKED);
        seatRepository.save(seat);
        log.info("Seat booked successfully: {}", seatId);
    }
}