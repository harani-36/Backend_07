package com.train.entity;

public enum SeatStatus {
	AVAILABLE,
	BOOKED

}
