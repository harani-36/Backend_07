package com.train.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="coach")
public class Coach {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String coachNumber;
	private String coachType;
	@ManyToOne
	@JoinColumn(name="journey_id")
	private Journey journey;
	@OneToMany(mappedBy = "coach", cascade = CascadeType.ALL)
	private List<Seat> seats;
	public Coach(Long id, String coachNumber, String coachType, Journey journey, List<Seat> seats) {
		super();
		this.id = id;
		this.coachNumber = coachNumber;
		this.coachType = coachType;
		this.journey = journey;
		this.seats = seats;
	}
	public Coach() {
		super();
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCoachNumber() {
		return coachNumber;
	}
	public void setCoachNumber(String coachNumber) {
		this.coachNumber = coachNumber;
	}
	public String getCoachType() {
		return coachType;
	}
	public void setCoachType(String coachType) {
		this.coachType = coachType;
	}
	public Journey getJourney() {
		return journey;
	}
	public void setJourney(Journey journey) {
		this.journey = journey;
	}
	public List<Seat> getSeats() {
		return seats;
	}
	public void setSeats(List<Seat> seats) {
		this.seats = seats;
	}
	
	

}
