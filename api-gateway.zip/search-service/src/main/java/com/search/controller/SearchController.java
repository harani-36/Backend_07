package com.search.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.search.client.TrainClient;
import com.search.dto.TrainResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/search")
@RequiredArgsConstructor
@Slf4j
public class SearchController {

    private final TrainClient trainClient;

    @GetMapping
    public List<TrainResponse> searchTrains(
            @RequestParam String source,
            @RequestParam String destination) {
        
        log.info("Searching trains from {} to {}", source, destination);
        List<TrainResponse> results = trainClient.getAllTrains()
                .stream()
                .filter(train ->
                        train.getSource().equalsIgnoreCase(source)
                        && train.getDestination().equalsIgnoreCase(destination))
                .toList();
        log.debug("Found {} trains", results.size());
        return results;
    }
}
