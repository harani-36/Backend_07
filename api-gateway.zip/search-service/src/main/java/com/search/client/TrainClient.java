package com.search.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.search.dto.TrainResponse;

@FeignClient(name = "train-service")
public interface TrainClient {

    @GetMapping("/trains")
    List<TrainResponse> getAllTrains();
}
