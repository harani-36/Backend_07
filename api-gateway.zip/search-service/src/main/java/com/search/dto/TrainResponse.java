package com.search.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TrainResponse {
    private Long id;
    private String trainNumber;
    private String name;
    private String source;
    private String destination;
}