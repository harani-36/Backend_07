package com.booking.service;

import com.booking.dto.BookingRequest;
import com.booking.dto.BookingResponse;
import com.booking.entity.Booking;

public interface BookingService {
	BookingResponse createBooking(BookingRequest request);
	Booking getBookingById(Long id);
	void confirmBooking(Long bookingId, Long paymentId);
	void cancelBooking(Long bookingId);
}
